//nút chuyển
btnf2.onclick = function() {
    if(username.value.trim() || email.value.trim() 
    || password.value.trim() || repassword.value.trim()){
        let cf = confirm('Do you want to change the page?');
        if(cf){
            //chuyển form và xóa các value
            reg_form.style.display = 'none';
            login_form.style.display = 'block';
            username.value = '';
            email.value = '';
            password.value = '';
            repassword.value = '';
        }
    } else if(!(username.value.trim() && email.value.trim() 
    && password.value.trim() && repassword.value.trim())){
        reg_form.style.display = 'none';
        login_form.style.display = 'block';
    }
}

let arrUser;
if(localStorage.getItem('Users')){
    arrUser = JSON.parse(localStorage.getItem('Users'));
} else {
    //nếu chưa có arrUser trong localStorage thì arrUser=[]
    arrUser = [];
    localStorage.setItem('Users', JSON.stringify(arrUser));
}

let User = {
    arr: arrUser,
    add: function (_username, _email, _password){
        let a = {
            id: this.arr.length + 1,
            username: _username,
            email: _email,
            password: _password,
            cart: []
        }
        this.arr.push(a);
    }
}

// User.add('admin', `admin@logo.com`, '123456');
// User.add('admin2', `admin2@logo.com`, '123456');
// localStorage.setItem('Users', JSON.stringify(User.arr));
// console.log(localStorage.getItem('Users'));

// Validation form
let form = document.querySelector('.auth__form');

let username = document.getElementById('username');
let email = document.getElementById('email');
let password = document.getElementById('password');
let repassword = document.getElementById('re-password');

let inputs = form.querySelectorAll('.input');

// Check bỏ trống
for(let i = 0 ; i < inputs.length ; i++){
    inputs[i].onblur = inputs[i].oninput = function() {
        if(inputs[i].value.trim()) {
            setSuccessFor(inputs[i]);
        } else {
            setErrorFor(inputs[i], 'This field cannot be left blank');
        }
    }
}

//check username <3 ký tự
username.onblur = username.oninput = function() {
    if(username.value.trim().length < 3) {
        setErrorFor(username, 'Username must be greater than 3 characters');
    } else {
        setSuccessFor(username);
    }
}

//regex email:
//https://stackoverflow.com/questions/46155/how-to-validate-an-email-address-in-javascript
function isEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
// Check email
email.onblur = email.oninput = function() {
    if(isEmail(email.value.trim())){
        setSuccessFor(email);
    } else {
        setErrorFor(email,'This field must be email');
    }
}

// Check password <6 ký tự
password.onblur = password.oninput = function() {
    if(password.value.trim().length < 6) {
        setErrorFor(password, 'Password must be greater than 6 characters');
    } else {
        setSuccessFor(password);
    }
}

// Check trùng password 
repassword.onblur = repassword.oninput = function() {
    if(repassword.value.trim() === password.value.trim()){
        setSuccessFor(repassword);
    } else {
        setErrorFor(repassword, 'Password does not match');
    }
}

function setErrorFor(input, message) {
    const formControl = input.parentElement;
    const small = formControl.querySelector('small');
    small.innerText = message;
    formControl.className = 'form-control invalid';
    input.focus();
}

function setSuccessFor(input) {
    const formControl = input.parentElement;
    const small = formControl.querySelector('small');
    small.innerText = '';
    formControl.className = 'form-control valid';
}

btnReg.onclick = function() {
    if(!(username.value.trim() || email.value.trim() 
    || password.value.trim() || repassword.value.trim())){
        alert('Please fill out all fields completely');
        if(!username.value.trim()) {
            setErrorFor(username,'This field cannot be left blank');
        }
        if(!email.value.trim()) {
            setErrorFor(email,'This field cannot be left blank');
        }
        if(!password.value.trim()) {
            setErrorFor(password,'This field cannot be left blank');
        }
        if(!repassword.value.trim()) {
            setErrorFor(repassword,'This field cannot be left blank');
        }
    } else if(username.value.trim() && email.value.trim() 
    && password.value.trim() && repassword.value.trim()){
        for(user of arrUser){
            if(user.username === username.value.trim()){
                alert('Username is ' + username.value.trim() + ' already taken, please choose another username!')
                setErrorFor(username, 'Username is already taken!');
                return;
            }
            if(user.email === email.value.trim()){
                alert('Email is ' + email.value.trim() + ' used!')
                setErrorFor(email, 'Email has been used!');
                return;
            }
        }
        //add user vào arr
        User.add(username.value.trim(), email.value.trim(), password.value.trim());
        localStorage.setItem('Users', JSON.stringify(User.arr));
        alert('You have successfully Sign up. Log in!');
        //hiện luôn form đăng nhập
        reg_form.style.display = 'none';
        login_form.style.display = 'block';
        usernameL.value = User.arr[User.arr.length-1].username;
    }
}


